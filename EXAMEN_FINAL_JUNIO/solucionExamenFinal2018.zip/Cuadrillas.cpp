/************************************/
/*   Modulo Cuadrillas.cpp          */
/*                                  */
/* Realizado por Isabel Pita        */
/* Modificado por Sonia Est�vez     */
/* Mayo 2018                        */
/*                                  */
/************************************/
#include <iostream>
using namespace std;

#include "Cuadrillas.h"
#include "checkML.h"


// Operaciones sobre la lista de cuadrillas
tListaCuadrillas inicializarListaCuadrilla(int tam){
	tListaCuadrillas l;
	l.listaCuadrilla = new tCuadrilla[tam];
	l.cont = 0;
	l.capacidad = tam;
	return l;
}

// Carga los datos a partir del fichero
tListaCuadrillas crearListaCuadrilla() {

	ifstream entrada;
	entrada.open("Cuadrillas.txt");
	tListaCuadrillas lista;
	if (entrada.is_open()) {
		int numCuadrillas;
		entrada >> numCuadrillas;
		lista = inicializarListaCuadrilla(numCuadrillas);
		for (int i = 0; i < numCuadrillas; ++i) {
				entrada >> lista.listaCuadrilla[i].id >> lista.listaCuadrilla[i].maxRecogida;
				lista.listaCuadrilla[i].parcelaAsignada = nullptr;
		}
		lista.cont = numCuadrillas;
		entrada.close();
	}
	else {      // Si el fichero no se abre se devuelve la lista vac�a
		lista = inicializarListaCuadrilla(0);
	}
	return lista;
}

// Asigna las parcelas a las cuadrillas
int asignarParcelas(tListaCuadrillas & lCuadrilla, tListaParcelas & lParcelas) {
	int i = 0; int j = 0;
	while (i < lParcelas.cont && j < lCuadrilla.cont) {
			int numPlatanos = lParcelas.listaParcelas[i]->numPlatanos;
			while (j < lCuadrilla.cont && numPlatanos > 0) {
				lCuadrilla.listaCuadrilla[j].parcelaAsignada = lParcelas.listaParcelas[i];
				numPlatanos -= lCuadrilla.listaCuadrilla[j].maxRecogida;
				j++;
			}
		i++;
	}
	return j;
}



void mostrarAsignacion(ostream & salida, tListaCuadrillas const& lCuadrillas,
	int numAsignadas){
	salida << "Parcela asignada a cada cuadrilla\n";
	salida << setw(33) << setfill('_') << '_' << setfill(' ') << "\n\n";
	salida << setw(10) << "Cuadrilla ";
	salida << setw(10) << "Capacidad";
	salida << setw(15) << "Plantacion";
	salida << setw(15) << "Parcela";
	salida << setw(10) << "Platanos en parcela" << endl;
	for (int i = 0; i < numAsignadas; ++i) {
		salida << setw(10) << lCuadrillas.listaCuadrilla[i].id;
		salida << setw(10) << lCuadrillas.listaCuadrilla[i].maxRecogida;
		salida << setw(15) << lCuadrillas.listaCuadrilla[i].parcelaAsignada->id;
		salida << setw(15) << lCuadrillas.listaCuadrilla[i].parcelaAsignada->coorx;
		salida << "," << lCuadrillas.listaCuadrilla[i].parcelaAsignada->coory;
		salida << setw(10) << lCuadrillas.listaCuadrilla[i].parcelaAsignada->numPlatanos << endl;
	}
}

void liberar(tListaCuadrillas & cuadrilla) {
	delete[] cuadrilla.listaCuadrilla;
	cuadrilla.listaCuadrilla = nullptr;
}

