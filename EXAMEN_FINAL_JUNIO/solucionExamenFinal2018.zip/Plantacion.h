/************************************/
/*   Modulo Plantacion.h            */
/*                                  */
/* Realizado por Isabel Pita        */
/* Modificado por Sonia Est�vez     */
/* Mayo 2018                        */
/*                                  */
/************************************/
#ifndef PLANTACION
#define PLANTACION

#include <string>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <math.h>
using namespace std;

// Tama�o m�ximo de la plantaci�n
const int TM = 100; 
// Tama�o m�ximo de la lista de parcelas
const int MAX_PARCELAS = 10000;

// Cada plantaci�n contiene:
// un identificador,
// el tama�o de la plantaci�n, 
// Una matriz con los pl�tanos de cada �rbol de la plantaci�n
typedef struct{
	string id;
	int numFilas, numColumnas;
	int plantacion[TM][TM];
}tPlantacion;

// Cada parcela contiene:
// un identificador que es el identificador de la plantaci�n
// la esquina superior izquierda
// y el n�mero de pl�tanos que contiene esa parcela
typedef struct{
	string id;
	int coorx, coory;
	int numPlatanos;
}tParcela;

// Lista est�tica de punteros a parcelas
typedef struct {
	tParcela* listaParcelas[MAX_PARCELAS];
	int cont;
}tListaParcelas;


// Prototipos

// Carga la estructura plantaci�n con los datos del fichero correspondiente 
bool cargar(tPlantacion & p);

// Funci�n utilizada en crearParcelas
tListaParcelas inicializarListaParcelas();

// Funci�n utilizada en crearParcelas
int calcularPlatanosParcela(const tPlantacion & p, int posx, int posy, int l);

// Crea la lista de parcelas a partir de una plantacion
tListaParcelas crearParcelas(tPlantacion const& p, int l);
int desplazar(tListaParcelas & lista, int k, int num);

// crea una lista a partir de otras dos manteniendo el orden
tListaParcelas mezclar(tListaParcelas const& l1, tListaParcelas const& l2);

// visualizar
void mostrarListaParcelas(ostream& salida, tListaParcelas const& lista, int ini);

void liberar(tListaParcelas & l);

#endif