/************************************/
/*   Modulo Cuadrillas.h            */
/*                                  */
/* Realizado por Isabel Pita        */
/* Modificado por Sonia Est�vez     */
/* Mayo 2018                        */
/*                                  */
/************************************/

#ifndef CUADRILLAS
#define CUADRILLAS

#include <iostream>
#include <string>
#include <fstream>
using namespace std;
#include "Plantacion.h"


// Tipo cuadrilla
typedef struct{
	string id;
	int maxRecogida;
	tParcela * parcelaAsignada;
}tCuadrilla;

typedef struct{
	tCuadrilla* listaCuadrilla;
	int cont;
	int capacidad;
}tListaCuadrillas;


// Inicializa una lista dando valor al contador
tListaCuadrillas inicializarListaCuadrilla(int tam);

// Carga los datos de las cuadrillas del fichero de entrada
tListaCuadrillas crearListaCuadrilla();

// Asigna las parcelas a las cuadrillas. 
// Primero asigna las parcelas que puede realizar una unica cuadrilla
// Luego asigna las parcelas que realiza mas de una cuadrilla
int asignarParcelas(tListaCuadrillas & lCuadrilla, tListaParcelas & lParcelas);
// Asigna las parcelas que puede realizar una unica cuadrilla
int asignarParcelasCompletas(tListaCuadrillas & lCuadrilla, tListaParcelas & lParcelas);
// Asigna las parcelas que realiza mas de una cuadrilla
int completarAsignacionParcelas(tListaCuadrillas & lCuadrilla, tListaParcelas & lParcelas, int j);

// Muestra las asignaciones realizadas
void mostrarAsignacion(ostream & salida, tListaCuadrillas const& lCuadrillas,
	int numAsignadas);

// Libera la memoria dinamica de la lista
void liberar(tListaCuadrillas & cuadrilla);

#endif