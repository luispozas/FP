/************************************/
/*   Programa principal             */
/*                                  */
/* Realizado por Isabel Pita        */
/* Modificado por Sonia Est�vez     */
/* Mayo 2018                        */
/*                                  */
/************************************/

#include <iostream>
#include <fstream>
#include <string>
using namespace std;
#include "Cuadrillas.h"
#include "Plantacion.h"
#include "checkML.h"

int main() {
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	// Se pide el lado de las parcelas
	int lado;
	cout << "  Introduzca la longitud del lado de las parcelas a crear ";
	cin >> lado;

	tPlantacion plantacion1, plantacion2;

	// Carga los datos de los ficheros y se crean las listas de parcelas

	if (cargar(plantacion1) && cargar(plantacion2)) {
		tListaParcelas lParcelas1 = crearParcelas(plantacion1, lado);
		tListaParcelas lParcelas2 = crearParcelas(plantacion2, lado);

		// Mostrar las parcelas
		cout << endl << " Lista de las parcelas de la plantacion1";
		mostrarListaParcelas(cout, lParcelas1, 0);
		cout << endl << " Lista de las parcelas de la plantacion2";
		mostrarListaParcelas(cout, lParcelas2, 0);

		tListaParcelas lParcelas = mezclar(lParcelas1, lParcelas2);

		// Crear una lista ordenada con los datos de todas las parcelas
		cout << endl << " Listado de las parcelas de ambas plantaciones ordenadas por el n�mero de pl�tanos a recoger ";
		mostrarListaParcelas(cout, lParcelas, 0);

		ofstream salida("Salida.txt");
		salida << endl << " Listado de las parcelas de ambas plantaciones ordenadas por el n�mero de pl�tanos a recoger ";
		mostrarListaParcelas(salida, lParcelas, 0);

		// Crea la lista de cuadrillas
		tListaCuadrillas lCuadrillas = crearListaCuadrilla();

		// Asigna las parcelas a las cuadrillas y muestra el resultado
		int numAsignadas = asignarParcelas(lCuadrillas, lParcelas);

		mostrarAsignacion(cout, lCuadrillas, numAsignadas);
		mostrarAsignacion(salida, lCuadrillas, numAsignadas);

		// Libera la memoria
		liberar(lCuadrillas);
		liberar(lParcelas);
	}
	else{
		cout << endl;
		cout << "  El programa no se ha podido ejecutar por un fallo en la carga de datos" << endl;
		cout << "  !!Se finaliza la ejecuci�n!!!" << endl;
	}

	system("PAUSE");
}