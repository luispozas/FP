/************************************/
/*   Modulo Plantaacion.cpp         */
/*                                  */
/* Realizado por Isabel Pita        */
/* Modificado por Sonia Est�vez     */
/* Mayo 2018                        */
/*                                  */
/************************************/
#include <fstream>
using namespace std;

#include "Plantacion.h"
#include "checkML.h"

// Rellena la matriz a partir de los datos del fichero
bool cargar(tPlantacion & p){
	cout << "  Introduce el nombre del fichero de la plantaci�n ";
	string id;
	cin >> id;

	bool ok = true;
	ifstream entrada;
	entrada.open(id + ".txt");   // no se obliga a concatenar ".txt". Se hace por comodidad en las pruebas
	if (entrada.is_open()) {
		entrada >> p.id;
		entrada >> p.numFilas >> p.numColumnas;
		for (int i = 0; i < p.numFilas; ++i){
			for (int j = 0; j < p.numColumnas; ++j)
				entrada >> p.plantacion[i][j];
		}
		entrada.close();
	}
	else{
		cout << "  No se ha cargado la plantacion" << endl;
		ok = false;
	}
	return ok;
}


tListaParcelas inicializarListaParcelas(){
	tListaParcelas lista;
	lista.cont = 0;
	return lista;
}

// Calcula los pl�tanos de la parcela de lado l cuya esquina superior izquierda esta en la pos (x,y)
int calcularPlatanosParcela(const tPlantacion & p, int posx, int posy, int l) {
	int suma = 0;
	int i = posx;
	while (i < p.numFilas && i < posx + l) {
		int j = posy;
		while (j < p.numColumnas && j < posy + l) {
			suma += p.plantacion[i][j];
			j++;
		}
		i++;
	}
	return suma;
}


// Funciones del tipo tListaParcelas

// Desplaza a la derecha desde la posicion k hasta que num sea mas peque�o.
// Devuelve la posicion donde queda el hueco
int desplazar(tListaParcelas & lista, int k, int num) {
	while (k > 0 && lista.listaParcelas[k - 1]->numPlatanos < num) {
		lista.listaParcelas[k] = lista.listaParcelas[k - 1];
		k--;
	}
	return k;
}

// Crea la lista de parcelas con la informacion de las plantaciones
tListaParcelas crearParcelas(tPlantacion const& p, int l) {
	tListaParcelas lista = inicializarListaParcelas();
	lista.cont = ((p.numFilas - 1) / l + 1) * ((p.numColumnas - 1) / l + 1);
	// da valor a las componentes del vector
	int k = 0;
	for (int i = 0; i < p.numFilas; i = i + l) {
		for (int j = 0; j < p.numColumnas; j = j + l) {
			int num = calcularPlatanosParcela(p, i, j, l);
			// La coloca en su sitio en orden creciente
			int pos = desplazar(lista, k, num);
			lista.listaParcelas[pos] = new tParcela;
			lista.listaParcelas[pos]->id = p.id;
			lista.listaParcelas[pos]->coorx = i;
			lista.listaParcelas[pos]->coory = j;
			lista.listaParcelas[pos]->numPlatanos = num;
			k++;
		}
	}
	return lista;
}

tListaParcelas mezclar(tListaParcelas const& l1, tListaParcelas const& l2){
	tListaParcelas l3 = inicializarListaParcelas();
	l3.cont = l1.cont + l2.cont;
	int i = 0; int j = 0; int k = 0;
	while (i < l1.cont && j < l2.cont) {
		if (l1.listaParcelas[i]->numPlatanos < l2.listaParcelas[j]->numPlatanos) {
			l3.listaParcelas[k] = l2.listaParcelas[j];
			j++;
		}
		else {
			l3.listaParcelas[k] = l1.listaParcelas[i];
			i++;
		}
		k++;
	}
	while (i < l1.cont) {
		l3.listaParcelas[k] = l1.listaParcelas[i];
		i++; k++;
	}
	while (j < l2.cont) {
		l3.listaParcelas[k] = l2.listaParcelas[j];
		j++; k++;
	}
	return l3;
}


void mostrarListaParcelas(ostream& salida, tListaParcelas const& lista, int ini) {
	if (ini == 0){
		salida << endl << endl;
		salida << setw(15) << "Id. Plant.";
		salida << setw(15) << "  Esq. sup-izq.";
		salida << setw(20) << "Pl�tanos a recoger" << endl;
	}

	if (ini < lista.cont) {
		salida << setw(15) << lista.listaParcelas[ini]->id;
		salida << setw(10) << lista.listaParcelas[ini]->coorx << ',' << lista.listaParcelas[ini]->coory;
		salida << setw(15) << lista.listaParcelas[ini]->numPlatanos << endl;
		mostrarListaParcelas(salida, lista, ini + 1);
	}
	else salida << '\n';
}



void liberar(tListaParcelas & l) {
	for (int i = 0; i < l.cont; ++i)
		delete l.listaParcelas[i];
}

